# Minesweeper (C# / .NET) — Class Library + Console App Solution

A text-based Minesweeper game split into a **class library** (Models +
Business logic) and a **console app** that references it via a project
reference — built and run from VS Code.

## Solution Structure

```
MinesweeperSolution/
├── Minesweeper.sln
├── Minesweeper.Library/                 ← class library project
│   ├── Minesweeper.Library.csproj
│   ├── Models/
│   │   ├── Cell.cs                      ← Cell class (data only)
│   │   ├── GameBoard.cs                  ← GameBoard class (data + constructor only)
│   │   ├── GameState.cs                  ← enum: InProgress, Won, Lost
│   │   └── DifficultyLevel.cs            ← enum: Easy=1, Medium=2, Hard=3
│   └── Business/
│       ├── BoardLogic.cs                 ← SetupBombs, CountBombsNearby,
│       │                                    DetermineGameState, UseSpecialBonus,
│       │                                    DetermineFinalScore
│       └── BoardPrinter.cs               ← PrintAnswers() and PrintPlayerView()
└── Minesweeper.Console/                 ← console app project
    ├── Minesweeper.Console.csproj        ← has a <ProjectReference> to the library
    └── Program.cs
```

## The project reference

`Minesweeper.Console.csproj` references the library like this:

```xml
<ItemGroup>
  <ProjectReference Include="..\Minesweeper.Library\Minesweeper.Library.csproj" />
</ItemGroup>
```

This lets `Program.cs` use `Minesweeper.Library.Models` and
`Minesweeper.Library.Business` types directly:

```csharp
using Minesweeper.Library.Business;
using Minesweeper.Library.Models;

var board = new GameBoard(10);     // 1. create an instance of GameBoard
var logic = new BoardLogic();
var printer = new BoardPrinter();

logic.SetupBombs(board);
logic.CountBombsNearby(board);
printer.PrintAnswers(board);        // 2. helper-class method that prints the board
```

## `PrintAnswers(GameBoard board)`

Lives on the new `BoardPrinter` class in the library's Business layer (so
`Program.cs` stays a thin caller with no formatting code of its own). It
prints the full "answer key" view of the board — every cell's true contents,
regardless of `IsVisited`/`IsFlagged` — intended as a debugging/testing aid
to confirm `SetupBombs` and `CountBombsNearby` are working correctly.

It satisfies every display requirement from the assignment:

- **Bombs print as `"B"`** (red).
- **Cells with neighboring bombs print the count** (1–8, yellow).
- **Cells with zero neighboring bombs print `"."`** (dark gray).
- **Column numbers** are printed across the top; **row numbers** are printed
  down the left side (both in cyan).
- **Divider lines** form a complete `+---+---+` grid outline around every
  cell, above and below every row.
- **`Console.ForegroundColor`** is used to color each symbol type
  differently, and is reset after every write so colors never bleed into
  later output.
- **Scales cleanly to any board size**, single-digit or double-digit. Column
  width is a fixed 4 characters per cell regardless of board size, and the
  row-label column automatically widens (`GetLabelWidth`) to fit the largest
  row number — so a 14×14 board's row "13" and column header "13" still line
  up perfectly with every other column, exactly like an 8×8 board's "7" does.

A normal (non-spoiler) `PrintPlayerView(board)` method also exists on the
same `BoardPrinter` class, used for the actual live gameplay loop so bombs
aren't visible while the player is still playing. `PrintAnswers` is reserved
for testing/debugging and for the "reveal everything" moment after the game
ends.

## Demo: two board sizes, side by side

`Program.cs` calls `PrintAnswers` on two boards back-to-back at startup,
before the interactive game begins:

- **Demo Board #1: size 8** (≤ 10 — single-digit row/column labels)
- **Demo Board #2: size 14** (> 10 — double-digit row/column labels)

This was specifically included so you can see, at a glance, that the
borders and number alignment hold up correctly at both scales.

## How to run this in VS Code

1. Install the **C# Dev Kit** (or **C#**) extension in VS Code.
2. Install the [.NET 8 SDK](https://dotnet.microsoft.com/download) if needed
   (`dotnet --version` should print `8.x`).
3. Open the `MinesweeperSolution` folder in VS Code.
4. Open a terminal (`` Ctrl+` ``) and run:
   ```bash
   dotnet build
   dotnet run --project Minesweeper.Console/Minesweeper.Console.csproj
   ```
   Or just press **F5** — the included `.vscode/launch.json` and
   `tasks.json` build the whole solution and launch `Minesweeper.Console`
   with the debugger attached.

## How to play (after the two-board PrintAnswers demo)

- `r c` — reveal the cell at row `r`, column `c` (e.g. `3 4`)
- `f r c` — toggle a flag on the cell at row `r`, column `c`
- `h` — spend a collected Hint reward to flag a random hidden bomb
- `q` — quit

## A note on testing

This project was written and carefully hand-reviewed in an environment
without network access or the .NET SDK installed (brace/paren balance,
namespace resolution across the two projects, and the exact character
widths the printer produces were verified with a standalone Python
simulation of the same centering/padding logic — confirmed identical output
widths for both the 8×8 and 14×14 demo boards). It could not be compiled or
run with the real `dotnet` toolchain before delivery. Please run
`dotnet build` first thing and let me know right away if anything doesn't
compile — happy to fix it immediately.
