using Minesweeper.Library.Business;
using Minesweeper.Library.Models;

namespace Minesweeper.ConsoleApp;

/// <summary>
/// Console entry point. This project only contains the console UI / game
/// loop - all Models (GameBoard, Cell) and Business logic (BoardLogic,
/// BoardPrinter) live in the referenced Minesweeper.Library class library
/// project (see the &lt;ProjectReference&gt; in Minesweeper.Console.csproj).
/// </summary>
public static class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("=========================================");
        Console.WriteLine("           MINESWEEPER (Console)");
        Console.WriteLine("=========================================");
        Console.WriteLine();

        // ------------------------------------------------------------
        // Required Main() steps:
        //   1. Create an instance of the GameBoard class.
        //   2. Call SetupBombs and CountBombsNearby to initialize the grid.
        //   3. Call PrintAnswers(board) to display the contents of the grid.
        // ------------------------------------------------------------
        GameBoard board = new GameBoard(10);          // 1. create an instance of the Board class
        BoardLogic logic = new BoardLogic();
        BoardPrinter printer = new BoardPrinter();

        logic.SetupBombs(board);                      // 2a. initialize the grid with bombs
        logic.CountBombsNearby(board);                // 2b. calculate each cell's neighbor count

        Console.WriteLine("--- Initial board (PrintAnswers) ---");
        printer.PrintAnswers(board);                  // 3. display the contents of the grid

        Console.WriteLine();
        Console.WriteLine("Press Enter to see the same demo at a larger (>10) board size...");
        Console.ReadLine();

        // ------------------------------------------------------------
        // Same three steps again, on a board over size 10, to confirm
        // PrintAnswers' column/row alignment holds up at double-digit
        // sizes too.
        // ------------------------------------------------------------
        GameBoard largeBoard = new GameBoard(14);
        logic.SetupBombs(largeBoard);
        logic.CountBombsNearby(largeBoard);

        Console.WriteLine("--- Larger board (size 14, PrintAnswers) ---");
        printer.PrintAnswers(largeBoard);

        Console.WriteLine();
        Console.WriteLine("Press Enter to start a playable game using your own board size...");
        Console.ReadLine();

        // ------------------------------------------------------------
        // Now play a real, interactive game.
        // ------------------------------------------------------------
        int size = PromptForBoardSize();
        DifficultyLevel difficulty = PromptForDifficulty();

        var gameBoard = new GameBoard(size) { Difficulty = difficulty };
        logic.SetupBombs(gameBoard);
        logic.CountBombsNearby(gameBoard);
        gameBoard.StartTime = DateTime.Now;

        Console.WriteLine();
        Console.WriteLine($"Board ready: {size}x{size}, Difficulty = {difficulty}.");
        Console.WriteLine("You will be asked for a row, a column, and an action each turn.");
        Console.WriteLine();

        RunGameLoop(gameBoard, logic, printer);
    }

    /// <summary>
    /// Displays the board during gameplay. Unlike PrintAnswers, this respects
    /// each cell's IsVisited property - unvisited cells show "?" instead of
    /// their true contents.
    /// </summary>
    private static void PrintBoard(GameBoard board, BoardPrinter printer)
    {
        printer.PrintPlayerView(board);
    }

    /// <summary>
    /// Main interactive loop: ask for a row, a column, and an action
    /// (visit / flag / use reward), apply it, then check the game state.
    /// </summary>
    private static void RunGameLoop(GameBoard board, BoardLogic logic, BoardPrinter printer)
    {
        while (board.GameState == GameState.InProgress)
        {
            PrintBoard(board, printer);

            Console.WriteLine("Enter the row number");
            int row = ReadIntWithinRange(board.Size);

            Console.WriteLine("Enter the column number");
            int col = ReadIntWithinRange(board.Size);

            Console.WriteLine("Enter 1 to visit the cell, 2 to flag the cell, 3 use a reward (Hint)");
            string? choice = Console.ReadLine()?.Trim();

            Cell cell = board.Cells[row, col];

            switch (choice)
            {
                case "1":
                    HandleVisit(board, logic, cell, row, col);
                    break;
                case "2":
                    HandleFlag(cell, row, col);
                    break;
                case "3":
                    string hintMessage = logic.UseSpecialBonus(board);
                    Console.WriteLine(hintMessage);
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please enter 1, 2, or 3.");
                    continue;
            }

            Console.WriteLine("Game in progress");
            logic.DetermineGameState(board);
        }

        // Game has ended (Won or Lost) - reveal the full answer-key board.
        board.EndTime = board.EndTime == default ? DateTime.Now : board.EndTime;

        Console.WriteLine();
        Console.WriteLine(board.GameState == GameState.Won
            ? "Congratulations! You won!"
            : "BOOM! You hit a bomb. Game over.");

        Console.WriteLine();
        Console.WriteLine("--- Final board (answer key) ---");
        printer.PrintAnswers(board);

        int finalScore = logic.DetermineFinalScore(board);
        TimeSpan elapsed = board.EndTime - board.StartTime;
        Console.WriteLine($"Time elapsed: {elapsed.TotalSeconds:F1} seconds.");
        Console.WriteLine($"Final score: {finalScore}");
    }

    /// <summary>
    /// Handles option 1: visiting (revealing) a cell. Delegates to
    /// BoardLogic.FloodFill (BLL) - the recursive reveal algorithm itself
    /// lives there, not in the console UI - and checks for a reward.
    /// </summary>
    private static void HandleVisit(GameBoard board, BoardLogic logic, Cell cell, int row, int col)
    {
        if (cell.IsFlagged)
        {
            Console.WriteLine("That cell is flagged. Unflag it first before visiting it.");
            return;
        }

        if (cell.IsVisited)
        {
            Console.WriteLine("That cell is already revealed.");
            return;
        }

        logic.FloodFill(board, row, col);

        if (cell.HasSpecialReward)
        {
            board.RewardsRemaining++;
            Console.WriteLine($"You found a reward! Rewards available: {board.RewardsRemaining}.");
        }
    }

    /// <summary>
    /// Handles option 2: toggling a flag on a not-yet-visited cell.
    /// </summary>
    private static void HandleFlag(Cell cell, int row, int col)
    {
        if (cell.IsVisited)
        {
            Console.WriteLine("You can't flag a cell that's already revealed.");
            return;
        }

        cell.IsFlagged = !cell.IsFlagged;
        Console.WriteLine(cell.IsFlagged
            ? $"Cell ({row},{col}) flagged."
            : $"Cell ({row},{col}) unflagged.");
    }

    /// <summary>
    /// Repeatedly prompts until the user enters a whole number that is a
    /// valid row or column index for the given board size (0 to size-1).
    /// </summary>
    private static int ReadIntWithinRange(int size)
    {
        while (true)
        {
            string? input = Console.ReadLine();

            if (int.TryParse(input, out int value) && value >= 0 && value < size)
            {
                return value;
            }

            Console.WriteLine($"Please enter a whole number between 0 and {size - 1}.");
        }
    }

    private static int PromptForBoardSize()
    {
        while (true)
        {
            Console.Write("Enter board size (e.g. 8 for an 8x8 grid): ");
            string? input = Console.ReadLine();

            if (int.TryParse(input, out int size) && size > 0 && size <= 50)
            {
                return size;
            }

            Console.WriteLine("Please enter a whole number between 1 and 50.");
        }
    }

    private static DifficultyLevel PromptForDifficulty()
    {
        while (true)
        {
            Console.Write("Choose difficulty - 1 (Easy), 2 (Medium), 3 (Hard): ");
            string? input = Console.ReadLine();

            switch (input?.Trim())
            {
                case "1":
                    return DifficultyLevel.Easy;
                case "2":
                    return DifficultyLevel.Medium;
                case "3":
                    return DifficultyLevel.Hard;
                default:
                    Console.WriteLine("Please enter 1, 2, or 3.");
                    break;
            }
        }
    }
}