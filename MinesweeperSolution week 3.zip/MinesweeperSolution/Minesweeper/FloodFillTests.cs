﻿using Minesweeper.Library.Business;
using Minesweeper.Library.Models;
using Xunit;

namespace Minesweeper.Tests;

/// <summary>
/// Unit tests for BoardLogic.FloodFill, the recursive algorithm that reveals
/// a connected block of zero-bomb-neighbor cells (Milestone 3).
/// </summary>
public class FloodFillTests
{
    [Fact]
    public void FloodFill_RevealsEntireBoard_WhenNoBombsArePresent()
    {
        // Arrange: a 4x4 board with zero bombs means every cell has
        // NumberOfBombNeighbors == 0, so flooding from any corner should
        // reveal the whole grid.
        var board = new GameBoard(4);
        var logic = new BoardLogic();
        logic.CountBombsNearby(board);

        // Act
        logic.FloodFill(board, 0, 0);

        // Assert
        foreach (Cell cell in board.Cells)
        {
            Assert.True(cell.IsVisited);
        }
    }

    [Fact]
    public void FloodFill_StopsAtNumberedCells_AndDoesNotRevealBeyondThem()
    {
        // Arrange: 5x5 board, single bomb at the center (2,2).
        // Cells touching the bomb become "numbered" cells (1-8) and should
        // be revealed (since they border the flood-filled region) but must
        // stop the recursion from spreading past them.
        var board = new GameBoard(5);
        board.Cells[2, 2].IsBomb = true;
        var logic = new BoardLogic();
        logic.CountBombsNearby(board);

        // Act: start the flood fill from the far corner, away from the bomb.
        logic.FloodFill(board, 0, 0);

        // Assert: the bomb cell itself must remain hidden - flood fill only
        // reveals cells the player could safely click, and a real player
        // would never flood-fill into an unrevealed bomb.
        Assert.False(board.Cells[2, 2].IsVisited);

        // The numbered cells bordering the bomb should be revealed (they
        // stop the flood but are still part of the connected reveal).
        Assert.True(board.Cells[1, 1].IsVisited);
        Assert.True(board.Cells[1, 2].IsVisited);
        Assert.True(board.Cells[3, 3].IsVisited);

        // Every non-bomb cell on this board should end up visited, since
        // the only obstruction is the single bomb at the center.
        foreach (Cell cell in board.Cells)
        {
            if (!cell.IsBomb)
            {
                Assert.True(cell.IsVisited);
            }
        }
    }

    [Fact]
    public void FloodFill_RevealsOnlyTheClickedCell_WhenItBordersABomb()
    {
        // Arrange: 3x3 board, bomb at (0,0). Cell (1,1) borders the bomb,
        // so it has NumberOfBombNeighbors > 0 and flood fill should reveal
        // only that single cell - no propagation to its neighbors.
        var board = new GameBoard(3);
        board.Cells[0, 0].IsBomb = true;
        var logic = new BoardLogic();
        logic.CountBombsNearby(board);

        // Act
        logic.FloodFill(board, 1, 1);

        // Assert
        Assert.True(board.Cells[1, 1].IsVisited);
        Assert.Equal(1, board.Cells[1, 1].NumberOfBombNeighbors);

        // A diagonally-adjacent cell that does NOT border the bomb and was
        // not the clicked cell should remain untouched.
        Assert.False(board.Cells[2, 2].IsVisited);
    }

    [Fact]
    public void FloodFill_RevealsClickedBombCell_ButDoesNotPropagate()
    {
        // Arrange: clicking directly on a bomb should still mark it visited
        // (so DetermineGameState can detect the loss) but must not recurse
        // into neighboring cells.
        var board = new GameBoard(3);
        board.Cells[1, 1].IsBomb = true;
        var logic = new BoardLogic();
        logic.CountBombsNearby(board);

        // Act
        logic.FloodFill(board, 1, 1);

        // Assert
        Assert.True(board.Cells[1, 1].IsVisited);
        Assert.False(board.Cells[0, 0].IsVisited);
        Assert.False(board.Cells[0, 1].IsVisited);
    }

    [Fact]
    public void FloodFill_DoesNothing_WhenStartingCellIsAlreadyVisited()
    {
        // Arrange
        var board = new GameBoard(3);
        var logic = new BoardLogic();
        logic.CountBombsNearby(board);
        board.Cells[1, 1].IsVisited = true;

        // Act: flood fill from an already-visited cell should be a no-op,
        // not re-trigger a fresh reveal of its neighbors.
        logic.FloodFill(board, 1, 1);

        // Assert
        Assert.False(board.Cells[0, 0].IsVisited);
        Assert.False(board.Cells[0, 1].IsVisited);
    }

    [Fact]
    public void FloodFill_DoesNothing_WhenStartingCellIsFlagged()
    {
        // Arrange
        var board = new GameBoard(3);
        var logic = new BoardLogic();
        logic.CountBombsNearby(board);
        board.Cells[1, 1].IsFlagged = true;

        // Act
        logic.FloodFill(board, 1, 1);

        // Assert: flagged cells are protected from being revealed.
        Assert.False(board.Cells[1, 1].IsVisited);
    }

    [Theory]
    [InlineData(-1, 0)]
    [InlineData(0, -1)]
    [InlineData(3, 0)]
    [InlineData(0, 3)]
    public void FloodFill_OutOfBoundsCoordinates_ReturnsWithoutThrowing(int row, int col)
    {
        // Arrange: a 3x3 board (valid indices 0-2). Recursive calls near the
        // edges will naturally generate out-of-bounds neighbor coordinates,
        // so the method must handle them gracefully instead of throwing.
        var board = new GameBoard(3);
        var logic = new BoardLogic();
        logic.CountBombsNearby(board);

        // Act & Assert (no exception expected)
        var exception = Record.Exception(() => logic.FloodFill(board, row, col));
        Assert.Null(exception);
    }

    [Fact]
    public void FloodFill_ConfinedRegion_DoesNotLeakPastAWallOfBombs()
    {
        // Arrange: 5x5 board with a full column of bombs at column 2,
        // splitting the board into a left half (columns 0-1) and a right
        // half (columns 3-4). Flooding from the left half must never reveal
        // any cell in the right half.
        var board = new GameBoard(5);
        for (int row = 0; row < 5; row++)
        {
            board.Cells[row, 2].IsBomb = true;
        }
        var logic = new BoardLogic();
        logic.CountBombsNearby(board);

        // Act
        logic.FloodFill(board, 0, 0);

        // Assert: left half (away from the bomb wall) fully revealed.
        for (int row = 0; row < 5; row++)
        {
            Assert.True(board.Cells[row, 0].IsVisited);
        }

        // Assert: right half was never reached.
        for (int row = 0; row < 5; row++)
        {
            Assert.False(board.Cells[row, 3].IsVisited);
            Assert.False(board.Cells[row, 4].IsVisited);
        }
    }
}