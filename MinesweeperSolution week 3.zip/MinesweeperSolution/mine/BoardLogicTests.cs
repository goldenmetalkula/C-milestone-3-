using Minesweeper.Library.Business;
using Minesweeper.Library.Models;
using Xunit;

namespace mine;

/// <summary>
/// Unit tests for BoardLogic, the class that contains all Minesweeper
/// gameplay behavior (bomb placement, neighbor counting, win/loss
/// detection, and reward handling).
///
/// A seeded Random is injected into BoardLogic wherever a test needs
/// deterministic, repeatable bomb/reward placement.
/// </summary>
public class BoardLogicTests
{
    [Fact]
    public void SetupBombs_PlacesCorrectNumberOfBombs_ForEasyDifficulty()
    {
        // Arrange: 10x10 board = 100 cells, Easy = 10% => 10 bombs expected.
        var board = new GameBoard(10) { Difficulty = DifficultyLevel.Easy };
        var logic = new BoardLogic(new Random(1));

        // Act
        logic.SetupBombs(board);

        // Assert
        int bombCount = CountBombs(board);
        Assert.Equal(10, bombCount);
    }

    [Fact]
    public void SetupBombs_PlacesCorrectNumberOfBombs_ForHardDifficulty()
    {
        // Arrange: 10x10 board = 100 cells, Hard = 24% => 24 bombs expected.
        var board = new GameBoard(10) { Difficulty = DifficultyLevel.Hard };
        var logic = new BoardLogic(new Random(1));

        // Act
        logic.SetupBombs(board);

        // Assert
        int bombCount = CountBombs(board);
        Assert.Equal(24, bombCount);
    }

    [Fact]
    public void SetupBombs_NeverPlacesMoreBombsThanCellsExist()
    {
        // Arrange: a tiny 2x2 board (4 cells) at Hard difficulty.
        var board = new GameBoard(2) { Difficulty = DifficultyLevel.Hard };
        var logic = new BoardLogic(new Random(1));

        // Act
        logic.SetupBombs(board);

        // Assert
        int bombCount = CountBombs(board);
        Assert.True(bombCount <= 4);
    }

    [Fact]
    public void CountBombsNearby_SetsNineOnBombCellsThemselves()
    {
        // Arrange: manually place a single bomb in the middle of a 3x3 board.
        var board = new GameBoard(3);
        board.Cells[1, 1].IsBomb = true;
        var logic = new BoardLogic();

        // Act
        logic.CountBombsNearby(board);

        // Assert
        Assert.Equal(9, board.Cells[1, 1].NumberOfBombNeighbors);
    }

    [Fact]
    public void CountBombsNearby_CorrectlyCountsAdjacentBombs()
    {
        // Arrange: place bombs in two of the eight neighbors of (1,1).
        var board = new GameBoard(3);
        board.Cells[0, 0].IsBomb = true; // neighbor of (1,1)
        board.Cells[0, 1].IsBomb = true; // neighbor of (1,1)
        var logic = new BoardLogic();

        // Act
        logic.CountBombsNearby(board);

        // Assert
        Assert.Equal(2, board.Cells[1, 1].NumberOfBombNeighbors);
    }

    [Fact]
    public void CountBombsNearby_CornerCell_OnlyCountsInBoundsNeighbors()
    {
        // Arrange: a bomb at (1,1) should count as a neighbor of corner (0,0),
        // and out-of-bounds positions around (0,0) must not throw or miscount.
        var board = new GameBoard(3);
        board.Cells[1, 1].IsBomb = true;
        var logic = new BoardLogic();

        // Act
        logic.CountBombsNearby(board);

        // Assert
        Assert.Equal(1, board.Cells[0, 0].NumberOfBombNeighbors);
    }

    [Fact]
    public void DetermineGameState_ReturnsStillPlaying_WhenUnvisitedSafeCellsRemain()
    {
        // Arrange: no cells visited yet, one bomb placed.
        var board = new GameBoard(3);
        board.Cells[0, 0].IsBomb = true;
        var logic = new BoardLogic();
        logic.CountBombsNearby(board);

        // Act
        string result = logic.DetermineGameState(board);

        // Assert
        Assert.Equal("StillPlaying", result);
        Assert.Equal(GameState.InProgress, board.GameState);
    }

    [Fact]
    public void DetermineGameState_ReturnsGameLost_WhenABombCellHasBeenVisited()
    {
        // Arrange
        var board = new GameBoard(3);
        board.Cells[0, 0].IsBomb = true;
        board.Cells[0, 0].IsVisited = true; // player stepped on the bomb
        var logic = new BoardLogic();
        logic.CountBombsNearby(board);

        // Act
        string result = logic.DetermineGameState(board);

        // Assert
        Assert.Equal("GameLost", result);
        Assert.Equal(GameState.Lost, board.GameState);
    }

    [Fact]
    public void DetermineGameState_ReturnsGameWon_WhenAllSafeCellsAreVisited()
    {
        // Arrange: 2x2 board, one bomb at (0,0). Visit every non-bomb cell.
        var board = new GameBoard(2);
        board.Cells[0, 0].IsBomb = true;
        board.Cells[0, 1].IsVisited = true;
        board.Cells[1, 0].IsVisited = true;
        board.Cells[1, 1].IsVisited = true;
        var logic = new BoardLogic();
        logic.CountBombsNearby(board);

        // Act
        string result = logic.DetermineGameState(board);

        // Assert
        Assert.Equal("GameWon", result);
        Assert.Equal(GameState.Won, board.GameState);
    }

    [Fact]
    public void UseSpecialBonus_ReturnsMessage_WhenNoRewardsAvailable()
    {
        // Arrange: a fresh board has RewardsRemaining = 0 by default.
        var board = new GameBoard(3);
        var logic = new BoardLogic();

        // Act
        string result = logic.UseSpecialBonus(board);

        // Assert
        Assert.Equal("No special rewards available to use.", result);
    }

    [Fact]
    public void UseSpecialBonus_FlagsAHiddenBomb_AndDecrementsRewardsRemaining()
    {
        // Arrange
        var board = new GameBoard(3);
        board.Cells[2, 2].IsBomb = true;
        board.RewardsRemaining = 1;
        var logic = new BoardLogic(new Random(1));

        // Act
        string result = logic.UseSpecialBonus(board);

        // Assert
        Assert.True(board.Cells[2, 2].IsFlagged);
        Assert.Equal(0, board.RewardsRemaining);
        Assert.Contains("Hint used!", result);
    }

    [Fact]
    public void UseSpecialBonus_DoesNotFlagAnAlreadyVisitedOrFlaggedBomb()
    {
        // Arrange: the only bomb is already flagged, so no hidden bombs remain.
        var board = new GameBoard(2);
        board.Cells[0, 0].IsBomb = true;
        board.Cells[0, 0].IsFlagged = true;
        board.RewardsRemaining = 1;
        var logic = new BoardLogic();

        // Act
        string result = logic.UseSpecialBonus(board);

        // Assert
        Assert.Equal("No hidden bombs remain to reveal as a hint.", result);
        Assert.Equal(1, board.RewardsRemaining); // unchanged
    }

    /// <summary>Helper: counts how many cells on the board have IsBomb == true.</summary>
    private static int CountBombs(GameBoard board)
    {
        int count = 0;
        for (int row = 0; row < board.Size; row++)
        {
            for (int col = 0; col < board.Size; col++)
            {
                if (board.Cells[row, col].IsBomb)
                {
                    count++;
                }
            }
        }
        return count;
    }
}
