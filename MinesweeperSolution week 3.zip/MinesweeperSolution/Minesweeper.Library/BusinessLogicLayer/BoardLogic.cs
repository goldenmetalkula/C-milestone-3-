using Minesweeper.Library.Models;

namespace Minesweeper.Library.Business;

/// <summary>
/// Contains all gameplay logic for Minesweeper: bomb placement, neighbor
/// counting, win/loss detection, special rewards, and scoring.
/// GameBoard stores data only; this class operates on it.
/// </summary>
public class BoardLogic
{
    private readonly Random _random;

    /// <param name="random">Optional injected Random for deterministic testing.</param>
    public BoardLogic(Random? random = null)
    {
        _random = random ?? new Random();
    }

    /// <summary>
    /// Places bombs and Hint rewards on the board.
    /// Bomb count is based on difficulty: Easy=10%, Medium=16%, Hard=24% of cells.
    /// Rewards are placed on non-bomb cells (~1 per 20 cells, minimum 1).
    /// Uses a Fisher-Yates shuffle to guarantee no duplicates and an exact count.
    /// </summary>
    public void SetupBombs(GameBoard board)
    {
        int totalCells = board.Size * board.Size;
        int bombCount = CalculateBombCount(board.Size, board.Difficulty);

        var allPositions = new List<(int row, int col)>(totalCells);
        for (int row = 0; row < board.Size; row++)
            for (int col = 0; col < board.Size; col++)
                allPositions.Add((row, col));

        Shuffle(allPositions);

        for (int i = 0; i < bombCount && i < allPositions.Count; i++)
        {
            var (row, col) = allPositions[i];
            board.Cells[row, col].IsBomb = true;
        }

        int rewardCount = Math.Max(1, totalCells / 20);
        int rewardsPlaced = 0;

        for (int i = bombCount; i < allPositions.Count && rewardsPlaced < rewardCount; i++)
        {
            var (row, col) = allPositions[i];
            board.Cells[row, col].HasSpecialReward = true;
            board.Cells[row, col].Reward = RewardType.Hint;
            rewardsPlaced++;
        }
    }

    /// <summary>
    /// Returns bomb count as a percentage of total cells, clamped to [1, totalCells].
    /// </summary>
    private static int CalculateBombCount(int size, DifficultyLevel difficulty)
    {
        int totalCells = size * size;
        double bombPercentage = difficulty switch
        {
            DifficultyLevel.Easy => 0.10,
            DifficultyLevel.Medium => 0.16,
            DifficultyLevel.Hard => 0.24,
            _ => 0.10
        };

        int bombCount = (int)Math.Round(totalCells * bombPercentage, MidpointRounding.AwayFromZero);
        return Math.Clamp(bombCount, 1, totalCells);
    }

    /// <summary>In-place Fisher-Yates shuffle.</summary>
    private void Shuffle<T>(List<T> list)
    {
        for (int i = list.Count - 1; i > 0; i--)
        {
            int j = _random.Next(i + 1);
            (list[i], list[j]) = (list[j], list[i]);
        }
    }

    /// <summary>
    /// Sets each cell's NumberOfBombNeighbors by counting adjacent bombs.
    /// Bomb cells are assigned 9 (impossible naturally) to distinguish them from safe cells.
    /// </summary>
    public void CountBombsNearby(GameBoard board)
    {
        for (int row = 0; row < board.Size; row++)
        {
            for (int col = 0; col < board.Size; col++)
            {
                Cell cell = board.Cells[row, col];
                cell.NumberOfBombNeighbors = cell.IsBomb ? 9 : CountAdjacentBombs(board, row, col);
            }
        }
    }

    /// <summary>Counts bombs in the up-to-8 neighbors of (row, col), skipping out-of-bounds.</summary>
    private static int CountAdjacentBombs(GameBoard board, int row, int col)
    {
        int count = 0;
        for (int dRow = -1; dRow <= 1; dRow++)
        {
            for (int dCol = -1; dCol <= 1; dCol++)
            {
                if (dRow == 0 && dCol == 0) continue;

                int nRow = row + dRow;
                int nCol = col + dCol;

                if (nRow >= 0 && nRow < board.Size && nCol >= 0 && nCol < board.Size
                    && board.Cells[nRow, nCol].IsBomb)
                {
                    count++;
                }
            }
        }
        return count;
    }

    /// <summary>
    /// Recursively reveals a connected region of cells starting at (row, col).
    /// A cell with zero adjacent bombs causes all 8 of its neighbors to be
    /// flood-filled as well. A cell that borders a bomb (NumberOfBombNeighbors
    /// greater than 0) is revealed but stops the recursion from spreading past
    /// it. Out-of-bounds coordinates, already-visited cells, and flagged cells
    /// are all no-ops. Clicking directly on a bomb reveals just that one bomb
    /// cell (so DetermineGameState can detect the loss) without propagating
    /// into its neighbors.
    /// </summary>
    public void FloodFill(GameBoard board, int row, int col)
    {
        if (row < 0 || row >= board.Size || col < 0 || col >= board.Size)
            return;

        Cell cell = board.Cells[row, col];

        if (cell.IsVisited || cell.IsFlagged)
            return;

        cell.IsVisited = true;

        // Bomb cells are revealed but must never propagate the flood further.
        if (cell.IsBomb)
            return;

        // Cells bordering a bomb are revealed but also stop the spread.
        if (cell.NumberOfBombNeighbors > 0)
            return;

        // Zero-neighbor cells: recurse into all 8 surrounding cells.
        for (int dRow = -1; dRow <= 1; dRow++)
        {
            for (int dCol = -1; dCol <= 1; dCol++)
            {
                if (dRow == 0 && dCol == 0) continue;
                FloodFill(board, row + dRow, col + dCol);
            }
        }
    }

    /// <summary>
    /// Returns "GameLost" if any bomb was visited, "GameWon" if all non-bomb cells
    /// are visited, or "StillPlaying" otherwise.
    /// Also updates board.GameState and stamps board.EndTime on game end.
    /// </summary>
    public string DetermineGameState(GameBoard board)
    {
        bool anyBombVisited = false;
        bool anyNonBombUnvisited = false;

        for (int row = 0; row < board.Size; row++)
        {
            for (int col = 0; col < board.Size; col++)
            {
                Cell cell = board.Cells[row, col];
                if (cell.IsBomb && cell.IsVisited) anyBombVisited = true;
                if (!cell.IsBomb && !cell.IsVisited) anyNonBombUnvisited = true;
            }
        }

        if (anyBombVisited)
        {
            board.GameState = GameState.Lost;
            if (board.EndTime == default) board.EndTime = DateTime.Now;
            return "GameLost";
        }

        if (!anyNonBombUnvisited)
        {
            board.GameState = GameState.Won;
            if (board.EndTime == default) board.EndTime = DateTime.Now;
            return "GameWon";
        }

        board.GameState = GameState.InProgress;
        return "StillPlaying";
    }

    /// <summary>
    /// Hint reward: flags one random, unflagged, unvisited bomb so the player
    /// can see its location without detonating it. Decrements RewardsRemaining.
    /// Returns a message describing the result.
    /// </summary>
    public string UseSpecialBonus(GameBoard board)
    {
        if (board.RewardsRemaining <= 0)
            return "No special rewards available to use.";

        var hiddenBombs = new List<Cell>();
        for (int row = 0; row < board.Size; row++)
            for (int col = 0; col < board.Size; col++)
            {
                Cell cell = board.Cells[row, col];
                if (cell.IsBomb && !cell.IsVisited && !cell.IsFlagged)
                    hiddenBombs.Add(cell);
            }

        if (hiddenBombs.Count == 0)
            return "No hidden bombs remain to reveal as a hint.";

        Cell chosen = hiddenBombs[_random.Next(hiddenBombs.Count)];
        chosen.IsFlagged = true;
        board.RewardsRemaining--;

        return $"Hint used! A bomb has been flagged at Row {chosen.Row}, Column {chosen.Column}.";
    }

    /// <summary>
    /// Calculates final score for a completed game:
    ///   BaseScore       = Size² × 10
    ///   DifficultyBonus = BaseScore × (0.5 × DifficultyLevel)
    ///   RewardBonus     = RewardsRemaining × 50
    ///   TimePenalty     = ElapsedSeconds × 2
    ///   FinalScore      = max(0, BaseScore + DifficultyBonus + RewardBonus - TimePenalty)
    /// </summary>
    public int DetermineFinalScore(GameBoard board)
    {
        double baseScore = board.Size * board.Size * 10;
        double difficultyBonus = baseScore * (0.5 * (int)board.Difficulty);
        double rewardBonus = board.RewardsRemaining * 50;

        TimeSpan elapsed = board.EndTime > board.StartTime ? board.EndTime - board.StartTime : TimeSpan.Zero;
        double timePenalty = elapsed.TotalSeconds * 2;

        return (int)Math.Max(0, Math.Round(baseScore + difficultyBonus + rewardBonus - timePenalty));
    }
}