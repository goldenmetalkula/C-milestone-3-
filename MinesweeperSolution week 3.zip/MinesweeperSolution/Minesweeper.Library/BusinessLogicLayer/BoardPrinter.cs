using Minesweeper.Library.Models;

namespace Minesweeper.Library.Business;

/// <summary>
/// Handles all console-printing for a GameBoard. Lives in the Business
/// layer so Program.cs stays a thin caller with no formatting logic.
/// </summary>
public class BoardPrinter
{
    // Characters reserved per cell, including its border.
    private const int CellWidth = 4;

    /// <summary>
    /// Prints the answer-key view: every cell's true contents regardless
    /// of visited/flagged state. Intended for debugging, not player use.
    /// Symbols: "B"=bomb, "."=safe/no neighbors, 1-8=neighbor bomb count.
    /// </summary>
    public void PrintAnswers(GameBoard board)
    {
        int size = board.Size;
        int labelWidth = GetLabelWidth(size);

        PrintColumnHeader(size, labelWidth);
        PrintHorizontalDivider(size, labelWidth);

        for (int row = 0; row < size; row++)
        {
            PrintRow(board, row, labelWidth);
            PrintHorizontalDivider(size, labelWidth);
        }

        Console.ResetColor();
    }

    /// <summary>
    /// Prints the player view: unrevealed cells show "#", flagged show "F",
    /// visited cells show their true contents. Pass revealAll=true (on loss)
    /// to also expose unvisited bombs as "B".
    /// </summary>
    public void PrintPlayerView(GameBoard board, bool revealAll = false)
    {
        int size = board.Size;
        int labelWidth = GetLabelWidth(size);

        PrintColumnHeader(size, labelWidth);
        PrintHorizontalDivider(size, labelWidth);

        for (int row = 0; row < size; row++)
        {
            PrintPlayerRow(board, row, labelWidth, revealAll);
            PrintHorizontalDivider(size, labelWidth);
        }

        Console.ResetColor();
    }

    private static void PrintPlayerRow(GameBoard board, int row, int labelWidth, bool revealAll)
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.Write(row.ToString().PadRight(labelWidth));
        Console.ResetColor();

        for (int col = 0; col < board.Size; col++)
        {
            Console.Write("|");
            PrintPlayerCellSymbol(board.Cells[row, col], revealAll);
        }

        Console.WriteLine("|");
    }

    private static void PrintPlayerCellSymbol(Cell cell, bool revealAll)
    {
        string symbol;
        ConsoleColor color;

        if (cell.IsFlagged)
        {
            symbol = "F"; color = ConsoleColor.Magenta;
        }
        else if (revealAll && cell.IsBomb)
        {
            symbol = "B"; color = ConsoleColor.Red;
        }
        else if (!cell.IsVisited)
        {
            symbol = "#"; color = ConsoleColor.Gray;
        }
        else if (cell.NumberOfBombNeighbors is > 0 and <= 8)
        {
            symbol = cell.NumberOfBombNeighbors.ToString(); color = ConsoleColor.Yellow;
        }
        else
        {
            symbol = "."; color = ConsoleColor.DarkGray;
        }

        Console.ForegroundColor = color;
        Console.Write(CenterText(symbol, CellWidth - 1));
        Console.ResetColor();
    }

    // Wide enough to fit the largest row number, minimum 2 characters.
    private static int GetLabelWidth(int size) =>
        Math.Max(2, (size - 1).ToString().Length + 1);

    private static void PrintColumnHeader(int size, int labelWidth)
    {
        Console.Write(new string(' ', labelWidth));
        for (int col = 0; col < size; col++)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write(CenterText(col.ToString(), CellWidth));
            Console.ResetColor();
        }
        Console.WriteLine();
    }

    // Horizontal divider of +---+---+ segments spanning the full board width.
    private static void PrintHorizontalDivider(int size, int labelWidth)
    {
        Console.Write(new string(' ', labelWidth));
        for (int col = 0; col < size; col++)
            Console.Write("+" + new string('-', CellWidth - 1));
        Console.WriteLine("+");
    }

    private static void PrintRow(GameBoard board, int row, int labelWidth)
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.Write(row.ToString().PadRight(labelWidth));
        Console.ResetColor();

        for (int col = 0; col < board.Size; col++)
        {
            Console.Write("|");
            PrintCellSymbol(board.Cells[row, col]);
        }

        Console.WriteLine("|");
    }

    // Colors: bomb=Red, numbered=Yellow, empty=DarkGray.
    private static void PrintCellSymbol(Cell cell)
    {
        string symbol;
        ConsoleColor color;

        if (cell.IsBomb)
        {
            symbol = "B"; color = ConsoleColor.Red;
        }
        else if (cell.NumberOfBombNeighbors > 0)
        {
            symbol = cell.NumberOfBombNeighbors.ToString(); color = ConsoleColor.Yellow;
        }
        else
        {
            symbol = "."; color = ConsoleColor.DarkGray;
        }

        Console.ForegroundColor = color;
        Console.Write(CenterText(symbol, CellWidth - 1));
        Console.ResetColor();
    }

    // Centers a string within a fixed-width field to keep grid columns aligned.
    private static string CenterText(string text, int width)
    {
        if (text.Length >= width) return text;

        int totalPadding = width - text.Length;
        int leftPadding = totalPadding / 2;
        return new string(' ', leftPadding) + text + new string(' ', totalPadding - leftPadding);
    }
}