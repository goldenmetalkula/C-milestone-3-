namespace Minesweeper.Library.Models;

/// <summary>
/// Special rewards granted when a cell is revealed.
/// </summary>
public enum RewardType
{
    None,
    Hint // Reveals one random hidden bomb location
}

/// <summary>
/// Data model for a single board cell. Contains state only; 
/// all game logic resides in the Business layer.
/// </summary>
public class Cell
{
    public int Row { get; set; } = -1;
    public int Column { get; set; } = -1;

    public bool IsVisited { get; set; }
    public bool IsBomb { get; set; }
    public bool IsFlagged { get; set; }

    /// <summary>
    /// Count of adjacent bombs (0-8). 
    /// NOTE: If this cell IS a bomb, this value is set to 9 by BoardLogic.
    /// </summary>
    public int NumberOfBombNeighbors { get; set; }

    public bool HasSpecialReward { get; set; }
    public RewardType Reward { get; set; }

    public Cell() { }

    public Cell(int row, int column)
    {
        Row = row;
        Column = column;
    }

    /// <summary>
    /// Returns the symbol for console display based on current state.
    /// Priority: Flag > Hidden > Bomb > Reward > Neighbor Count.
    /// </summary>
    public string GetDisplaySymbol()
    {
        if (IsFlagged) return "F";
        if (!IsVisited) return "#";
        if (IsBomb) return "*";
        if (HasSpecialReward) return "R";

        // Show count if > 0, otherwise blank space
        return NumberOfBombNeighbors == 0 ? "." : NumberOfBombNeighbors.ToString();
    }

    public override string ToString() =>
        $"Cell({Row}, {Column}, Bomb={IsBomb}, Visited={IsVisited}, Neighbors={NumberOfBombNeighbors})";
}