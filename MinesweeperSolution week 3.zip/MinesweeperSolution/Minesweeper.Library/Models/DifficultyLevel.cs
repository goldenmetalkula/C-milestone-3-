namespace Minesweeper.Library.Models;

/// <summary>
/// Difficulty tiers. The numeric value determines bomb count in BoardLogic.SetupBombs.
/// </summary>
public enum DifficultyLevel
{
    Easy = 1,
    Medium = 2,
    Hard = 3
}