namespace Minesweeper.Library.Models;

/// <summary>
/// Pure data model for the game board. Stores state only; 
/// all gameplay logic resides in Business.BoardLogic.
/// </summary>
public class GameBoard
{
    /// <summary>
    /// Board dimension (square grid). Size = rows = columns.
    /// </summary>
    public int Size { get; }

    public DateTime StartTime { get; set; }
    public DateTime EndTime { get; set; }

    /// <summary>
    /// 2D grid of cells. Indexed as Cells[row, column].
    /// </summary>
    public Cell[,] Cells { get; }

    /// <summary>
    /// Difficulty tier. Determines bomb density in BoardLogic.
    /// </summary>
    public DifficultyLevel Difficulty { get; set; }

    /// <summary>
    /// Count of collected special rewards (from revealing HasSpecialReward cells).
    /// </summary>
    public int RewardsRemaining { get; set; }

    public GameState GameState { get; set; } = GameState.InProgress;

    /// <summary>
    /// Initializes a square grid of Cells with coordinates.
    /// </summary>
    /// <param name="size">Board dimension (must be > 0).</param>
    public GameBoard(int size)
    {
        if (size <= 0)
            throw new ArgumentOutOfRangeException(nameof(size), "Board size must be positive.");

        Size = size;
        Cells = new Cell[size, size];

        for (int row = 0; row < size; row++)
            for (int col = 0; col < size; col++)
                Cells[row, col] = new Cell(row, col);

        Difficulty = DifficultyLevel.Easy;
        StartTime = DateTime.Now;
    }
}