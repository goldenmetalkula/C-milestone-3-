namespace Minesweeper.Library.Models;

/// <summary>
/// Represents the current state of a Minesweeper game.
/// </summary>
public enum GameState
{
    InProgress,
    Won,
    Lost
}
